package operating;

import java.sql.ResultSet;
import java.util.List;

import database.BBSDatabase;
import entity.Reply;
import tool.ToolReply;

public class OperatingReply {
	private static BBSDatabase bbsDatabase = BBSDatabase.getDatabase();

	/////////////////////////////////////////// ���뿪ʼ////////////////////////////////////////////////////
	// ����һ���ظ�
	public static boolean insertAReply(Reply reply) {
		reply = ToolReply.completionTopic(reply);
		int i = bbsDatabase.executeUpdate(ToolReply.entityToStringInsert(reply).toString());
		return i > 0;
	}

	/////////////////////////////////////////// �������////////////////////////////////////////////////////
	
	/////////////////////////////////////////// ɾ����ʼ////////////////////////////////////////////////////
	// ɾ��һ���ظ�
	public static boolean deleteAReply(Reply reply) {
		int i = bbsDatabase.executeUpdate("delete form user where session='" + reply.getId() + "';");
		return i > 0;
	}

	/////////////////////////////////////////// ɾ������////////////////////////////////////////////////////
	
	/////////////////////////////////////////// �޸Ŀ�ʼ////////////////////////////////////////////////////
	// �޸�һ���ظ�
	public static boolean modifyAReply(Reply reply) {
		int i = bbsDatabase.executeUpdate(ToolReply.entityToStringModify(reply).toString());
		return i > 0;
	}

	/////////////////////////////////////////// �޸Ľ���////////////////////////////////////////////////////

	/////////////////////////////////////////// ��ѯ��ʼ////////////////////////////////////////////////////
	// ����ID��ȡһ����ϸ�Ļظ���Ϣ
	public static Reply getAReplyById(Reply reply) {
		ResultSet resultSet = bbsDatabase.executeQuery("select * from reply where id='" + reply.getId() + "';");
		return ToolReply.resultSetToList(resultSet).get(0);
	}

	// ��ȡϵͳ���лظ���Ϣ
	public static List<Reply> getAllReply() {
		ResultSet resultSet = bbsDatabase.executeQuery("select * from reply;");
		return ToolReply.resultSetToList(resultSet);
	}
	/////////////////////////////////////////// ��ѯ����////////////////////////////////////////////////////

}
