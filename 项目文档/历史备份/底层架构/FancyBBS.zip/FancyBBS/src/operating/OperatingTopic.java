package operating;

import java.sql.ResultSet;
import java.util.List;

import database.BBSDatabase;
import entity.Topic;
import tool.ToolTopic;

public class OperatingTopic {
	private static BBSDatabase bbsDatabase = BBSDatabase.getDatabase();

	/////////////////////////////////////////// ���뿪ʼ////////////////////////////////////////////////////
	// ����һ������
	public static boolean insertATopic(Topic topic) {
		topic = ToolTopic.completionTopic(topic);
		int i = bbsDatabase.executeUpdate(ToolTopic.entityToStringInsert(topic).toString());
		return i > 0;
	}
	/////////////////////////////////////////// �������////////////////////////////////////////////////////

	/////////////////////////////////////////// ɾ����ʼ////////////////////////////////////////////////////
	// ɾ��һ������
	public static boolean deleteATopic(Topic topic) {
		int i = bbsDatabase.executeUpdate("delete form topic where id='" + topic.getId() + "';");
		return i > 0;
	}
	/////////////////////////////////////////// ɾ������////////////////////////////////////////////////////

	/////////////////////////////////////////// �޸Ŀ�ʼ////////////////////////////////////////////////////
	// �޸�һ������
	public static boolean modifyATopic(Topic topic) {
		int i = bbsDatabase.executeUpdate(ToolTopic.entityToStringModify(topic).toString());
		return i > 0;
	}

	/////////////////////////////////////////// �޸Ľ���////////////////////////////////////////////////////

	/////////////////////////////////////////// ��ѯ��ʼ////////////////////////////////////////////////////
	// ����ID��ѯ����
	public static Topic getATopicById(Topic topic) {
		ResultSet resultSet = bbsDatabase.executeQuery("select * from topic where id='" + topic.getId() + "';");
		return ToolTopic.resultSetToList(resultSet).get(0);
	}

	// ����Topic��ѯ����
	public static Topic getATopicByTopic(Topic topic) {
		ResultSet resultSet = bbsDatabase.executeQuery("select * from topic where topic='" + topic.getTopic() + "';");
		return ToolTopic.resultSetToList(resultSet).get(0);
	}

	// ��ȡϵͳ���л�����Ϣ
	public static List<Topic> getAllTopic() {
		ResultSet resultSet = bbsDatabase.executeQuery("select * from topic;");
		return ToolTopic.resultSetToList(resultSet);
	}
	/////////////////////////////////////////// ��ѯ����////////////////////////////////////////////////////

}
